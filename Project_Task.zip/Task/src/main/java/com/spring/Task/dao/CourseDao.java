
package com.spring.Task.dao;



import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.Task.entities.Course;

public interface CourseDao extends JpaRepository<Course, Long> {

	public Course JpaRepositorygetbyId(long courseId);
}
